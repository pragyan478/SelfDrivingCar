when compiling the code

g++ -std=c++11 tests.cpp

