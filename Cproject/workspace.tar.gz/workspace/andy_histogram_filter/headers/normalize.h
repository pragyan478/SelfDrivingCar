#ifndef NORMALIZE_H
#define NORMALIZE_H

#include <vector>

std::vector < std::vector <float> > normalize(std::vector < std::vector <float> > grid);

#endif /* NORMALIZE.H */