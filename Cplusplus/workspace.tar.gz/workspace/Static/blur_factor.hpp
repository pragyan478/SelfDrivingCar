#ifndef blur_factor_hpp
#define blur_factor_hpp

#include <vector>
std::vector < std::vector <float> > blur_factor();

#endif /* blur_factor_hpp */
