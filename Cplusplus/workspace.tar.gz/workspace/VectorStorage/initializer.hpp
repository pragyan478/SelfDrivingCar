#ifndef initializer_hpp
#define initializer_hpp

#include <vector>

std::vector < std::vector<int> > initializer(int rows, int cols, int initial_value);

#endif /* initializer_hpp */
