int main() {
  
  	int x;
  	x = 5;  
 	return 0; 
}